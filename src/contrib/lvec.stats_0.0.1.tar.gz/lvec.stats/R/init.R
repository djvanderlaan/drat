
.onUnload <- function (libpath) {
  library.dynam.unload("lvec.stats", libpath)
}

