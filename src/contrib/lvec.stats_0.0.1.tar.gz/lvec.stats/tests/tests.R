library(lvec.stats)
library(testthat)

test_check("lvec.stats")

