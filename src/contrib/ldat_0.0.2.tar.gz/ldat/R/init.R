
.onUnload <- function (libpath) {
  library.dynam.unload("ldat", libpath)
}

